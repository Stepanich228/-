let arr = [1, 2, 3, 4, 5];
let printArrayElements = () => {
  for (let i = 0; i < arr.length; i++) {
    console.log(arr[i]);
  }
};

printArrayElements();
